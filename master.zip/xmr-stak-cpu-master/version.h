#pragma once

#define XMR_STAK_NAME "xmr-stak-cpu"
#define XMR_STAK_VERSION "1.3.0-1.5.0"
