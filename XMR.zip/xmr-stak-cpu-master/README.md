# XMR-Stak is now supporting CPU, AMD and NVIDIA GPUs in a unified miner.

Our new repository is https://github.com/fireice-uk/xmr-stak.

Please use our new miner, the old version is retired and unsupported.
